"""Small checks for the extracted algorithm-only implementation."""

import numpy as np

from financial_sde_algorithms.convergence import gbm_strong_convergence
from financial_sde_algorithms.gbm import simulate_gbm_terminal
from financial_sde_algorithms.nonaffine import (
    aggregate_increments,
    correlated_brownian_increments,
    logistic_vol,
    simulate_nonaffine_terminal,
)
from financial_sde_algorithms.parameters import GBMParameters, NonAffineParameters


def require(condition: bool, message: str) -> None:
    if not condition:
        raise AssertionError(message)
    print(f"PASS: {message}")


def main() -> None:
    constant = GBMParameters(mu=0.0, sigma=0.0)
    exact, euler, milstein, _, _ = simulate_gbm_terminal(
        constant, n_paths=20, n_steps=8, rng=np.random.default_rng(1)
    )
    require(np.all(exact == constant.s0), "zero-coefficient exact GBM is constant")
    require(np.all(euler == constant.s0), "zero-coefficient EM is constant")
    require(np.all(milstein == constant.s0), "zero-coefficient Milstein is constant")

    fine = np.arange(24.0).reshape(3, 8)
    coarse = aggregate_increments(fine, factor=4)
    require(
        np.allclose(np.sum(fine, axis=1), np.sum(coarse, axis=1)),
        "fine-to-coarse aggregation preserves each Brownian path total",
    )

    nonaffine = NonAffineParameters()
    volatility = logistic_vol(np.array([-1000.0, 0.0, 1000.0]), nonaffine)
    require(
        np.isfinite(volatility).all()
        and np.all(volatility >= nonaffine.sigma_min)
        and np.all(volatility <= nonaffine.sigma_max),
        "logistic volatility stays finite and bounded",
    )

    rng = np.random.default_rng(2)
    h = nonaffine.maturity / 64
    dw1, dw2 = correlated_brownian_increments(5000, 64, h, nonaffine.rho, rng)
    sample_rho = float(np.corrcoef(dw1.ravel(), dw2.ravel())[0, 1])
    require(abs(sample_rho - nonaffine.rho) < 0.01, "Brownian correlation matches rho")
    terminal_s, terminal_y = simulate_nonaffine_terminal(nonaffine, dw1, dw2, h)
    require(
        np.isfinite(terminal_s).all()
        and np.isfinite(terminal_y).all()
        and np.all(terminal_s > 0.0),
        "non-affine terminal states are finite and prices are positive",
    )

    result = gbm_strong_convergence(
        GBMParameters(),
        step_counts=(8, 16, 32, 64, 128),
        n_paths=40_000,
        seed=20260918,
    )
    print(f"Estimated EM strong order: {result['euler_order']:.3f}")
    print(f"Estimated Milstein strong order: {result['milstein_order']:.3f}")
    require(0.40 < result["euler_order"] < 0.65, "EM strong order is near 1/2")
    require(0.85 < result["milstein_order"] < 1.15, "Milstein strong order is near 1")


if __name__ == "__main__":
    main()
