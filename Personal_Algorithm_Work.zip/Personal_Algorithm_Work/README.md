# Personal algorithm work: Financial SDEs

This directory contains only the mathematical and numerical algorithm layer
extracted from `Python代码第二版.py`.  It deliberately contains no plotting,
LaTeX generation, saved figures, or group-level `run_all.py` wrapper.

## Files

- `financial_sde_algorithms/parameters.py`: model parameters.
- `financial_sde_algorithms/gbm.py`: exact GBM, Euler--Maruyama (EM), and
  Milstein updates driven by the same Brownian increments.
- `financial_sde_algorithms/nonaffine.py`: correlated Brownian increments,
  bounded logistic volatility, log-price EM, and fine-to-coarse increment
  aggregation for the two-factor non-affine model.
- `financial_sde_algorithms/convergence.py`: confidence intervals, log--log
  slope fitting, and numerical convergence experiments without any figures.
- `check_algorithms.py`: small deterministic and statistical checks.

The only third-party dependency is NumPy.

## Run

From this directory:

```bash
python check_algorithms.py
```

The checks are intentionally small.  They verify the implementation rather
than reproduce all high-cost Monte Carlo results in the report.

## How the GBM code follows the mathematics

The GBM model is

```text
dS_t = mu S_t dt + sigma S_t dW_t.
```

For one time step of length `h`, the code draws `Z ~ N(0,1)` and sets
`dW = sqrt(h) Z`.

The exact update is

```text
S_{n+1} = S_n exp((mu - sigma^2/2)h + sigma dW).
```

Euler--Maruyama is

```text
S_{n+1} = S_n (1 + mu h + sigma dW).
```

Milstein adds the scalar correction

```text
S_{n+1} = S_n [1 + mu h + sigma dW
               + (sigma^2/2)((dW)^2 - h)].
```

All three methods use exactly the same `dW` at every step.  This coupling is
essential: the terminal differences then measure discretisation error rather
than differences caused by unrelated random paths.

## How the non-affine code follows the mathematics

The project uses the two-factor model

```text
dS_t = mu S_t dt + g(Y_t) S_t dW1_t,
dY_t = kappa(theta - Y_t)dt + xi sqrt(1 + Y_t^2)dW2_t,
Corr(dW1_t, dW2_t) = rho,
g(y) = sigma_min + (sigma_max - sigma_min)/(1 + exp(-y)).
```

The price equation is simulated through `X_t = log(S_t)`.  Ito's formula gives

```text
dX_t = (mu - g(Y_t)^2/2)dt + g(Y_t)dW1_t.
```

Therefore one EM step is

```text
X_{n+1} = X_n + (mu - g(Y_n)^2/2)h + g(Y_n)dW1_n,
Y_{n+1} = Y_n + kappa(theta - Y_n)h
                + xi sqrt(1 + Y_n^2)dW2_n,
S_{n+1} = exp(X_{n+1}).
```

Using the log-price makes every returned asset price positive.  Correlated
increments are constructed from independent standard normals `Z1, Z2`:

```text
dW1 = sqrt(h) Z1,
dW2 = sqrt(h) [rho Z1 + sqrt(1-rho^2) Z2].
```

For a fair coarse/fine comparison, a coarse increment is the sum of the fine
increments inside that coarse interval.  The function `aggregate_increments`
implements precisely this nesting.

## How to read the code

Read it in this order:

1. `parameters.py`: identify every symbol in the SDEs.
2. `gbm.py`: follow one loop iteration and match each factor with the three
   formulas above.
3. `nonaffine.py`: first read `correlated_brownian_increments`, then
   `logistic_vol`, then `simulate_nonaffine_terminal`.
4. `convergence.py`: see how terminal errors from many coupled paths become
   Monte Carlo means, confidence intervals, and fitted convergence orders.
5. Run `check_algorithms.py`, change only `n_paths` or `n_steps`, and observe
   which numerical quantities change.

You should be able to explain four points orally: why `sqrt(h)` multiplies a
standard normal, why the same increments are shared, where the Milstein term
comes from, and why fine increments are summed instead of regenerated.

## Git evidence

This folder can be uploaded to your own branch as your algorithm contribution.
Do not backdate commits and do not claim code you cannot explain.  A natural
sequence, after you have read and run each part, is:

1. add `parameters.py` and `gbm.py`;
2. add `nonaffine.py`;
3. add `convergence.py`, `check_algorithms.py`, and this explanation.

Example commit messages:

```text
Implement coupled exact, EM and Milstein GBM updates
Implement nested EM solver for the non-affine model
Add convergence calculations and algorithm checks
```

