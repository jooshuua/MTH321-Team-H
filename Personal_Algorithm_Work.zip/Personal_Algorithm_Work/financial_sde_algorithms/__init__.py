"""Numerical algorithms for the MTH321 Financial SDE project."""

from .parameters import GBMParameters, NonAffineParameters
from .gbm import simulate_gbm_terminal
from .nonaffine import (
    aggregate_increments,
    correlated_brownian_increments,
    logistic_vol,
    simulate_nonaffine_terminal,
)

__all__ = [
    "GBMParameters",
    "NonAffineParameters",
    "simulate_gbm_terminal",
    "aggregate_increments",
    "correlated_brownian_increments",
    "logistic_vol",
    "simulate_nonaffine_terminal",
]
