"""Nested Euler--Maruyama algorithms for the two-factor non-affine model."""

import math

import numpy as np

from .parameters import NonAffineParameters


def logistic_vol(
    y: np.ndarray, parameters: NonAffineParameters
) -> np.ndarray:
    """Evaluate the bounded logistic volatility without exponential overflow."""
    values = np.asarray(y, dtype=float)
    positive = values >= 0.0
    logistic = np.empty_like(values)
    logistic[positive] = 1.0 / (1.0 + np.exp(-values[positive]))
    exp_y = np.exp(values[~positive])
    logistic[~positive] = exp_y / (1.0 + exp_y)

    width = parameters.sigma_max - parameters.sigma_min
    return parameters.sigma_min + width * logistic


def correlated_brownian_increments(
    n_paths: int,
    n_steps: int,
    h: float,
    rho: float,
    rng: np.random.Generator,
) -> tuple[np.ndarray, np.ndarray]:
    """Generate Brownian increments with variance h and correlation rho."""
    if n_paths <= 0 or n_steps <= 0 or h <= 0.0:
        raise ValueError("n_paths, n_steps and h must be positive")
    if not -1.0 <= rho <= 1.0:
        raise ValueError("rho must lie in [-1, 1]")

    z1 = rng.standard_normal((n_paths, n_steps))
    z2 = rng.standard_normal((n_paths, n_steps))
    sqrt_h = math.sqrt(h)
    dw1 = sqrt_h * z1
    dw2 = sqrt_h * (rho * z1 + math.sqrt(1.0 - rho**2) * z2)
    return dw1, dw2


def aggregate_increments(dw_fine: np.ndarray, factor: int) -> np.ndarray:
    """Sum adjacent fine increments to obtain a nested coarse Brownian path."""
    values = np.asarray(dw_fine, dtype=float)
    if values.ndim != 2:
        raise ValueError("dw_fine must have shape (n_paths, n_fine_steps)")
    if factor <= 0 or values.shape[1] % factor != 0:
        raise ValueError("factor must be positive and divide n_fine_steps")

    n_paths, n_fine_steps = values.shape
    return values.reshape(n_paths, n_fine_steps // factor, factor).sum(axis=2)


def simulate_nonaffine_terminal(
    parameters: NonAffineParameters,
    dw1: np.ndarray,
    dw2: np.ndarray,
    h: float,
) -> tuple[np.ndarray, np.ndarray]:
    """Return terminal (S, Y) using log-price Euler--Maruyama updates."""
    first = np.asarray(dw1, dtype=float)
    second = np.asarray(dw2, dtype=float)
    if first.ndim != 2 or first.shape != second.shape:
        raise ValueError("dw1 and dw2 must be two-dimensional arrays of equal shape")
    if h <= 0.0:
        raise ValueError("h must be positive")

    p = parameters
    n_paths, n_steps = first.shape
    x = np.full(n_paths, math.log(p.s0), dtype=float)
    y = np.full(n_paths, p.y0, dtype=float)

    for step in range(n_steps):
        volatility = logistic_vol(y, p)
        x += (
            (p.mu - 0.5 * volatility**2) * h
            + volatility * first[:, step]
        )
        y += (
            p.kappa * (p.theta - y) * h
            + p.xi * np.sqrt(1.0 + y**2) * second[:, step]
        )

    return np.exp(x), y
