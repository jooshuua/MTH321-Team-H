"""Numerical convergence calculations with no plotting or file output."""

import math

import numpy as np

from .gbm import simulate_gbm_terminal
from .nonaffine import (
    aggregate_increments,
    correlated_brownian_increments,
    simulate_nonaffine_terminal,
)
from .parameters import GBMParameters, NonAffineParameters


def mean_ci95(samples: np.ndarray) -> tuple[float, float, float]:
    """Sample mean and normal-approximation 95 percent confidence interval."""
    values = np.asarray(samples, dtype=float)
    if values.size < 2:
        raise ValueError("at least two samples are required")
    mean = float(np.mean(values))
    half_width = 1.96 * float(np.std(values, ddof=1)) / math.sqrt(values.size)
    return mean, mean - half_width, mean + half_width


def fitted_loglog_slope(step_sizes: np.ndarray, errors: np.ndarray) -> float:
    """Fit log(error) = intercept + slope*log(h) by least squares."""
    h = np.asarray(step_sizes, dtype=float)
    e = np.asarray(errors, dtype=float)
    if h.shape != e.shape or h.size < 2 or np.any(h <= 0) or np.any(e <= 0):
        raise ValueError("positive h and error arrays of equal length are required")
    slope, _ = np.polyfit(np.log(h), np.log(e), 1)
    return float(slope)


def gbm_strong_convergence(
    parameters: GBMParameters,
    step_counts: tuple[int, ...],
    n_paths: int,
    seed: int,
) -> dict[str, object]:
    """Estimate strong errors and fitted orders for EM and Milstein."""
    rows: list[dict[str, float | int]] = []
    for n_steps in step_counts:
        rng = np.random.default_rng(seed + n_steps)
        exact, euler, milstein, _, _ = simulate_gbm_terminal(
            parameters, n_paths, n_steps, rng
        )
        euler_ci = mean_ci95(np.abs(euler - exact))
        milstein_ci = mean_ci95(np.abs(milstein - exact))
        rows.append(
            {
                "n_steps": n_steps,
                "h": parameters.maturity / n_steps,
                "euler_mae": euler_ci[0],
                "euler_ci_low": euler_ci[1],
                "euler_ci_high": euler_ci[2],
                "milstein_mae": milstein_ci[0],
                "milstein_ci_low": milstein_ci[1],
                "milstein_ci_high": milstein_ci[2],
            }
        )

    h = np.array([row["h"] for row in rows], dtype=float)
    euler_error = np.array([row["euler_mae"] for row in rows], dtype=float)
    milstein_error = np.array([row["milstein_mae"] for row in rows], dtype=float)
    return {
        "rows": rows,
        "euler_order": fitted_loglog_slope(h, euler_error),
        "milstein_order": fitted_loglog_slope(h, milstein_error),
    }


def nonaffine_nested_errors(
    parameters: NonAffineParameters,
    coarse_step_counts: tuple[int, ...],
    reference_steps: int,
    n_paths: int,
    seed: int,
) -> dict[str, object]:
    """Compare coarse EM paths with a nested fine-grid reference."""
    if any(reference_steps % n != 0 for n in coarse_step_counts):
        raise ValueError("reference_steps must be divisible by every coarse count")

    p = parameters
    h_reference = p.maturity / reference_steps
    rng = np.random.default_rng(seed)
    fine_dw1, fine_dw2 = correlated_brownian_increments(
        n_paths, reference_steps, h_reference, p.rho, rng
    )
    reference_s, _ = simulate_nonaffine_terminal(
        p, fine_dw1, fine_dw2, h_reference
    )

    rows: list[dict[str, float | int]] = []
    for n_steps in coarse_step_counts:
        factor = reference_steps // n_steps
        coarse_dw1 = aggregate_increments(fine_dw1, factor)
        coarse_dw2 = aggregate_increments(fine_dw2, factor)
        coarse_s, _ = simulate_nonaffine_terminal(
            p, coarse_dw1, coarse_dw2, p.maturity / n_steps
        )
        interval = mean_ci95(np.abs(coarse_s - reference_s))
        rows.append(
            {
                "n_steps": n_steps,
                "h": p.maturity / n_steps,
                "mae_vs_reference": interval[0],
                "ci_low": interval[1],
                "ci_high": interval[2],
            }
        )

    h = np.array([row["h"] for row in rows], dtype=float)
    errors = np.array([row["mae_vs_reference"] for row in rows], dtype=float)
    return {"rows": rows, "empirical_order": fitted_loglog_slope(h, errors)}
