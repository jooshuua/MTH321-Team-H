"""Parameter containers for the two SDE models."""

from dataclasses import dataclass


@dataclass(frozen=True)
class GBMParameters:
    """Parameters of dS = mu*S*dt + sigma*S*dW."""

    s0: float = 100.0
    mu: float = 0.05
    sigma: float = 0.40
    maturity: float = 1.0


@dataclass(frozen=True)
class NonAffineParameters:
    """Parameters of the two-factor non-affine stochastic-volatility model."""

    s0: float = 100.0
    y0: float = 0.0
    mu: float = 0.05
    kappa: float = 2.0
    theta: float = -0.2
    xi: float = 0.6
    rho: float = -0.7
    sigma_min: float = 0.10
    sigma_max: float = 0.50
    maturity: float = 1.0
    strike: float = 100.0
