"""Exact, Euler--Maruyama and Milstein algorithms for scalar GBM."""

import math

import numpy as np

from .parameters import GBMParameters


def simulate_gbm_terminal(
    parameters: GBMParameters,
    n_paths: int,
    n_steps: int,
    rng: np.random.Generator,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """Return coupled exact, EM and Milstein terminal values.

    The same Brownian increment is used by all three schemes at each step.
    The last two arrays record whether a path ever used a non-positive EM or
    Milstein multiplier.
    """
    if n_paths <= 0 or n_steps <= 0:
        raise ValueError("n_paths and n_steps must be positive")

    p = parameters
    h = p.maturity / n_steps
    sqrt_h = math.sqrt(h)

    exact = np.full(n_paths, p.s0, dtype=float)
    euler = exact.copy()
    milstein = exact.copy()
    euler_ever_nonpositive = np.zeros(n_paths, dtype=bool)
    milstein_ever_nonpositive = np.zeros(n_paths, dtype=bool)

    for _ in range(n_steps):
        z = rng.standard_normal(n_paths)
        dw = sqrt_h * z

        exact_factor = np.exp(
            (p.mu - 0.5 * p.sigma**2) * h + p.sigma * dw
        )
        euler_factor = 1.0 + p.mu * h + p.sigma * dw
        milstein_factor = euler_factor + 0.5 * p.sigma**2 * (dw**2 - h)

        euler_ever_nonpositive |= euler_factor <= 0.0
        milstein_ever_nonpositive |= milstein_factor <= 0.0

        exact *= exact_factor
        euler *= euler_factor
        milstein *= milstein_factor

    return (
        exact,
        euler,
        milstein,
        euler_ever_nonpositive,
        milstein_ever_nonpositive,
    )
